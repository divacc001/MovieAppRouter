
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import {  useLocation, useNavigate, useParams } from 'react-router-dom';
import { MDBBtn } from 'mdb-react-ui-kit';

function Trailers() {
  const options = {
    method: 'GET',
    headers: {
      accept: 'application/json', 
      Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJhM2JhNzY0MjkyMTdmNmIxZDkzNzQzMDA0ODkzMWJmMyIsInN1YiI6IjY1Y2U3MTU2NTQzN2Y1MDE3YzQxMWUzYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.T8Yk1CqlM4LmMPaHwHmLqABzAG6iQNKH-EhIPIxCYQM'
    }
  };
 const {movieId}=useParams()
 const location = useLocation();
 const description = location.state?.description;
 const [trailerUrl, setTrailerUrl] = useState('');

const navigate=useNavigate()
  useEffect(() => {
    axios.get(`https://api.themoviedb.org/3/movie/${movieId}/videos`,options)
  .then(response => {
    const trailers = response.data.results.filter(video => video.type === "Trailer");
    if (trailers.length > 0) {
      const trailerKey = trailers[0].key;
      setTrailerUrl(`https://www.youtube-nocookie.com/embed/${trailerKey}`);
    }
  })
  .catch(error => {
    console.error('Error fetching trailer: ', error);
  });
  }, [movieId]);
  console.log(trailerUrl)
  return (
    <> 
    <div style={{marginTop:"50px"}}>
    <MDBBtn outline rounded onClick={()=>navigate('/')}>
        Movie List
      </MDBBtn>
    </div>
     
    <div style={{display:"flex",flexDirection:"column", gap:"50px", marginTop:"50px", alignItems:"center"}}>
    
    <h3>Trailer</h3>
      <div className="ratio ratio-16x9" style={{width:"1000px"}}>

      <iframe
        src={trailerUrl}
        title="YouTube video"
        allowFullScreen  
             >

      </iframe>
    </div>
    <div> <h5>Desription</h5>
<p> {description} </p></div>


    </div>
    </>
   
  )
}

export default Trailers
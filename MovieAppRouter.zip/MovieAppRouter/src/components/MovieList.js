import MovieCard from "./MovieCard";
import Filter from "./Filter";
import AddMovie from "./AddMovie";
function MovieList({ movies,addNewMovie, filterList}) {
    console.log(movies);

    return (
        <div>  
        <h1 style={{
            textAlign: "center",
            marginBottom: "50px",
            fontSize: "36px",
            color: "#333333",
            fontWeight: "bold",
            paddingTop: "20px"
          }}> List of Movies </h1>
                <div style={{ display: "flex", justifyContent: "space-around", gap: "600px" }}>

<Filter movie={movies} filterList={filterList} />
<AddMovie addNewMovie={addNewMovie} />
</div>
                <div style={{ display: 'flex', flexWrap: "wrap", justifyContent: "space-around", gap: "20px" }}>
                    {movies.map(movie => (
                        <MovieCard key={movie.id} movie={movie} />
                    ))}
           
        </div>
        </div>
    );
}

export default MovieList;

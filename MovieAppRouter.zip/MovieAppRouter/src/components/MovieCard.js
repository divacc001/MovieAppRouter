import React from 'react'
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { useNavigate } from 'react-router-dom';

function MovieCard({ movie }) {
  const navigate=useNavigate()

  const showTrailer=()=>{
navigate(`/movieTrailer/${movie.id}`, { state: { description: movie.description } });

  }

  return (


    <Card style={{ width: '18rem', marginBottom: "20px" }}>
      <Card.Img variant="top" src={movie.posterURL} />
      <Card.Body>
        <Card.Title>{movie.title}</Card.Title>
        <Card.Text>
          {movie.description}
        </Card.Text>
        <Card.Text>
          <h5 style={{ color: 'blue', fontSize: '18px' }}> rating: {isNaN(parseFloat(movie.rating)) ? 'N/A' : parseFloat(movie.rating).toFixed(1)}</h5>
        </Card.Text>
              <Button variant="dark" onClick={showTrailer}>Trailer</Button>

      </Card.Body>
    </Card>

  )
}

export default MovieCard
import React, { useState } from 'react';
import { MDBInputGroup, MDBInput, MDBIcon, MDBBtn } from 'mdb-react-ui-kit';

export default function Filter({ filterList }) {
  const [title, setTitle] = useState("")
  const handleClick = () => {

    console.log(title)
    filterList(title)
  }
  return (
    <MDBInputGroup style={{ width: "350px", marginBottom: "40px", marginLeft: "20px" }}>
      <MDBInput value={title} id='Search' label='Search' onChange={(e) => setTitle(e.target.value)}
        size='lg' />
      <MDBBtn rippleColor='dark' onClick={handleClick}>
        <MDBIcon icon='search' />
      </MDBBtn>
    </MDBInputGroup>
  );
}